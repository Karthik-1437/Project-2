
import React, { useState, useMemo, useCallback } from 'react';
import type { Project, Expense } from './types';
import Header from './components/Header';
import ProjectList from './components/ProjectList';
import ProjectDetails from './components/ProjectDetails';
import Modal from './components/Modal';

const initialProjects: Project[] = [
  {
    id: 'proj-1',
    name: 'Kitchen Renovation',
    budget: 15000,
    expenses: [
      { id: 'exp-1', description: 'New Cabinets', amount: 4500, category: 'Materials', date: new Date().toISOString() },
      { id: 'exp-2', description: 'Countertops', amount: 3200, category: 'Materials', date: new Date().toISOString() },
      { id: 'exp-3', description: 'Labor - Installation', amount: 2500, category: 'Labor', date: new Date().toISOString() },
      { id: 'exp-4', description: 'Appliances', amount: 3000, category: 'Appliances', date: new Date().toISOString() },
    ],
  },
  {
    id: 'proj-2',
    name: 'Garden Landscaping',
    budget: 5000,
    expenses: [
      { id: 'exp-5', description: 'Plants and Soil', amount: 1200, category: 'Gardening', date: new Date().toISOString() },
      { id: 'exp-6', description: 'Patio Stones', amount: 800, category: 'Hardscaping', date: new Date().toISOString() },
      { id: 'exp-7', description: 'Gardener Fee', amount: 1000, category: 'Labor', date: new Date().toISOString() },
    ],
  },
];

const App: React.FC = () => {
  const [projects, setProjects] = useState<Project[]>(initialProjects);
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(initialProjects.length > 0 ? initialProjects[0].id : null);
  const [isProjectModalOpen, setIsProjectModalOpen] = useState(false);
  const [isExpenseModalOpen, setIsExpenseModalOpen] = useState(false);

  const selectedProject = useMemo(() => {
    return projects.find(p => p.id === selectedProjectId) || null;
  }, [projects, selectedProjectId]);

  const handleSelectProject = useCallback((id: string) => {
    setSelectedProjectId(id);
  }, []);

  const handleCreateProject = useCallback((name: string, budget: number) => {
    const newProject: Project = {
      id: `proj-${Date.now()}`,
      name,
      budget,
      expenses: [],
    };
    setProjects(prev => [...prev, newProject]);
    setSelectedProjectId(newProject.id);
    setIsProjectModalOpen(false);
  }, []);

  const handleAddExpense = useCallback((description: string, amount: number, category: string) => {
    if (!selectedProjectId) return;
    const newExpense: Expense = {
      id: `exp-${Date.now()}`,
      description,
      amount,
      category,
      date: new Date().toISOString(),
    };
    setProjects(prev => prev.map(p =>
      p.id === selectedProjectId
        ? { ...p, expenses: [...p.expenses, newExpense] }
        : p
    ));
    setIsExpenseModalOpen(false);
  }, [selectedProjectId]);
  
  const handleDeleteProject = useCallback((id: string) => {
      setProjects(prev => prev.filter(p => p.id !== id));
      if (selectedProjectId === id) {
          setSelectedProjectId(projects.length > 1 ? projects.filter(p => p.id !== id)[0].id : null);
      }
  }, [selectedProjectId, projects]);

  return (
    <div className="min-h-screen bg-slate-100">
      <Header />
      <main className="container mx-auto p-4 md:p-6 lg:p-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <div className="lg:col-span-4 xl:col-span-3">
            <ProjectList
              projects={projects}
              selectedProjectId={selectedProjectId}
              onSelectProject={handleSelectProject}
              onAddProject={() => setIsProjectModalOpen(true)}
              onDeleteProject={handleDeleteProject}
            />
          </div>
          <div className="lg:col-span-8 xl:col-span-9">
            <ProjectDetails
              project={selectedProject}
              onAddExpense={() => setIsExpenseModalOpen(true)}
            />
          </div>
        </div>
      </main>

      <Modal
        isOpen={isProjectModalOpen}
        onClose={() => setIsProjectModalOpen(false)}
        title="Create New Project"
      >
        <ProjectForm onSubmit={handleCreateProject} onCancel={() => setIsProjectModalOpen(false)} />
      </Modal>

      <Modal
        isOpen={isExpenseModalOpen}
        onClose={() => setIsExpenseModalOpen(false)}
        title="Add New Expense"
      >
        <ExpenseForm onSubmit={handleAddExpense} onCancel={() => setIsExpenseModalOpen(false)} />
      </Modal>
    </div>
  );
};


interface ProjectFormProps {
    onSubmit: (name: string, budget: number) => void;
    onCancel: () => void;
}
const ProjectForm: React.FC<ProjectFormProps> = ({ onSubmit, onCancel }) => {
    const [name, setName] = useState('');
    const [budget, setBudget] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const budgetValue = parseFloat(budget);
        if (name && !isNaN(budgetValue) && budgetValue > 0) {
            onSubmit(name, budgetValue);
        }
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-4">
            <div>
                <label htmlFor="projectName" className="block text-sm font-medium text-slate-700">Project Name</label>
                <input
                    type="text"
                    id="projectName"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-sky-500 focus:border-sky-500 sm:text-sm"
                    required
                />
            </div>
            <div>
                <label htmlFor="projectBudget" className="block text-sm font-medium text-slate-700">Budget ($)</label>
                <input
                    type="number"
                    id="projectBudget"
                    value={budget}
                    onChange={(e) => setBudget(e.target.value)}
                    className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-sky-500 focus:border-sky-500 sm:text-sm"
                    required
                    min="0.01"
                    step="0.01"
                />
            </div>
            <div className="flex justify-end space-x-3 pt-2">
                <button type="button" onClick={onCancel} className="px-4 py-2 text-sm font-medium text-slate-700 bg-slate-100 border border-transparent rounded-md hover:bg-slate-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-slate-500">
                    Cancel
                </button>
                <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-sky-600 border border-transparent rounded-md shadow-sm hover:bg-sky-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-sky-500">
                    Create Project
                </button>
            </div>
        </form>
    );
};

interface ExpenseFormProps {
    onSubmit: (description: string, amount: number, category: string) => void;
    onCancel: () => void;
}

const ExpenseForm: React.FC<ExpenseFormProps> = ({ onSubmit, onCancel }) => {
    const [description, setDescription] = useState('');
    const [amount, setAmount] = useState('');
    const [category, setCategory] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const amountValue = parseFloat(amount);
        if (description && category && !isNaN(amountValue) && amountValue > 0) {
            onSubmit(description, amountValue, category);
        }
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-4">
            <div>
                <label htmlFor="expenseDescription" className="block text-sm font-medium text-slate-700">Description</label>
                <input
                    type="text"
                    id="expenseDescription"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-sky-500 focus:border-sky-500 sm:text-sm"
                    required
                />
            </div>
             <div>
                <label htmlFor="expenseCategory" className="block text-sm font-medium text-slate-700">Category</label>
                <input
                    type="text"
                    id="expenseCategory"
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-sky-500 focus:border-sky-500 sm:text-sm"
                    required
                    placeholder="e.g., Materials, Labor, Appliances"
                />
            </div>
            <div>
                <label htmlFor="expenseAmount" className="block text-sm font-medium text-slate-700">Amount ($)</label>
                <input
                    type="number"
                    id="expenseAmount"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-sky-500 focus:border-sky-500 sm:text-sm"
                    required
                    min="0.01"
                    step="0.01"
                />
            </div>
            <div className="flex justify-end space-x-3 pt-2">
                 <button type="button" onClick={onCancel} className="px-4 py-2 text-sm font-medium text-slate-700 bg-slate-100 border border-transparent rounded-md hover:bg-slate-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-slate-500">
                    Cancel
                </button>
                <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-sky-600 border border-transparent rounded-md shadow-sm hover:bg-sky-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-sky-500">
                    Add Expense
                </button>
            </div>
        </form>
    );
};

export default App;
