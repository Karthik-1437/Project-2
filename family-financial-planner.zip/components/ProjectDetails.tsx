
import React from 'react';
import type { Project } from '../types';
import ExpenseChart from './ExpenseChart';
import AiAdvisor from './AiAdvisor';
import PlusIcon from './icons/PlusIcon';

interface ProjectDetailsProps {
  project: Project | null;
  onAddExpense: () => void;
}

const ProjectDetails: React.FC<ProjectDetailsProps> = ({ project, onAddExpense }) => {
  if (!project) {
    return (
      <div className="bg-white rounded-lg shadow-md p-8 h-full flex items-center justify-center">
        <div className="text-center">
          <svg className="mx-auto h-12 w-12 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
          </svg>
          <h3 className="mt-2 text-lg font-medium text-slate-900">Select a project</h3>
          <p className="mt-1 text-sm text-slate-500">Choose a project from the list to see its details.</p>
        </div>
      </div>
    );
  }

  const totalSpent = project.expenses.reduce((sum, exp) => sum + exp.amount, 0);
  const remaining = project.budget - totalSpent;
  const progress = project.budget > 0 ? (totalSpent / project.budget) * 100 : 0;

  const getProgressColor = (p: number) => {
    if (p > 100) return 'bg-red-500';
    if (p > 80) return 'bg-yellow-500';
    return 'bg-emerald-500';
  }

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-3xl font-bold text-slate-800 mb-2">{project.name}</h2>
        
        {/* Financial Summary */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4 text-center">
          <div className="p-4 bg-slate-50 rounded-lg">
            <p className="text-sm font-medium text-slate-500">Budget</p>
            <p className="text-2xl font-semibold text-slate-800">${project.budget.toLocaleString()}</p>
          </div>
          <div className="p-4 bg-slate-50 rounded-lg">
            <p className="text-sm font-medium text-slate-500">Spent</p>
            <p className="text-2xl font-semibold text-sky-600">${totalSpent.toLocaleString()}</p>
          </div>
          <div className="p-4 bg-slate-50 rounded-lg">
            <p className="text-sm font-medium text-slate-500">Remaining</p>
            <p className={`text-2xl font-semibold ${remaining >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
              ${remaining.toLocaleString()}
            </p>
          </div>
        </div>
        
        {/* Progress Bar */}
        <div className="w-full bg-slate-200 rounded-full h-4">
          <div
            className={`${getProgressColor(progress)} h-4 rounded-full transition-all duration-500`}
            style={{ width: `${Math.min(progress, 100)}%` }}
          ></div>
        </div>
        {progress > 100 && <p className="text-sm text-red-600 text-center mt-1">Over budget!</p>}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-xl font-bold text-slate-800 mb-4">Spending by Category</h3>
            <div className="h-64">
              <ExpenseChart expenses={project.expenses} />
            </div>
        </div>
        <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-xl font-bold text-slate-800 mb-4">AI Financial Advisor</h3>
            <AiAdvisor project={project} />
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md">
        <div className="flex justify-between items-center p-6 border-b border-slate-200">
          <h3 className="text-xl font-bold text-slate-800">Expenses</h3>
          <button onClick={onAddExpense} className="flex items-center space-x-2 px-4 py-2 text-sm font-medium text-white bg-sky-600 border border-transparent rounded-md shadow-sm hover:bg-sky-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-sky-500">
            <PlusIcon className="w-4 h-4"/>
            <span>Add Expense</span>
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-slate-200">
            <thead className="bg-slate-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Description</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Category</th>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-slate-500 uppercase tracking-wider">Amount</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-slate-200">
              {project.expenses.length > 0 ? project.expenses.map(exp => (
                <tr key={exp.id}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-900">{exp.description}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">{exp.category}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500 text-right">${exp.amount.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
                </tr>
              )) : (
                <tr>
                    <td colSpan={3} className="text-center py-10 px-6 text-sm text-slate-500">No expenses added yet.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default ProjectDetails;
