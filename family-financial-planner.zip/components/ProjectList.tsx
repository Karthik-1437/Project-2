
import React from 'react';
import type { Project } from '../types';
import PlusIcon from './icons/PlusIcon';
import TrashIcon from './icons/TrashIcon';

interface ProjectListProps {
  projects: Project[];
  selectedProjectId: string | null;
  onSelectProject: (id: string) => void;
  onAddProject: () => void;
  onDeleteProject: (id: string) => void;
}

const ProjectList: React.FC<ProjectListProps> = ({ projects, selectedProjectId, onSelectProject, onAddProject, onDeleteProject }) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-4 h-full">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold text-slate-800">Projects</h2>
        <button
          onClick={onAddProject}
          className="p-2 rounded-full text-sky-600 bg-sky-100 hover:bg-sky-200 focus:outline-none focus:ring-2 focus:ring-sky-500 focus:ring-offset-2"
          aria-label="Add new project"
        >
          <PlusIcon className="w-5 h-5" />
        </button>
      </div>
      <div className="space-y-2">
        {projects.map(project => {
          const totalSpent = project.expenses.reduce((sum, exp) => sum + exp.amount, 0);
          const progress = project.budget > 0 ? (totalSpent / project.budget) * 100 : 0;
          const isSelected = project.id === selectedProjectId;

          return (
            <div
              key={project.id}
              onClick={() => onSelectProject(project.id)}
              className={`group p-4 rounded-lg cursor-pointer transition-all duration-200 ${
                isSelected
                  ? 'bg-sky-100 border-l-4 border-sky-500 shadow'
                  : 'hover:bg-slate-100 hover:shadow-sm'
              }`}
            >
              <div className="flex justify-between items-start">
                  <div>
                    <h3 className={`font-semibold ${isSelected ? 'text-sky-700' : 'text-slate-700'}`}>
                      {project.name}
                    </h3>
                    <p className="text-sm text-slate-500">
                      Spent ${totalSpent.toLocaleString()} of ${project.budget.toLocaleString()}
                    </p>
                  </div>
                  <button
                      onClick={(e) => {
                          e.stopPropagation();
                          if (window.confirm(`Are you sure you want to delete "${project.name}"?`)) {
                              onDeleteProject(project.id);
                          }
                      }}
                      className="p-1.5 rounded-full text-slate-400 hover:bg-red-100 hover:text-red-600 opacity-0 group-hover:opacity-100 transition-opacity"
                      aria-label={`Delete ${project.name}`}
                  >
                      <TrashIcon className="w-4 h-4" />
                  </button>
              </div>
              <div className="mt-2">
                <div className="w-full bg-slate-200 rounded-full h-2">
                  <div
                    className="bg-sky-500 h-2 rounded-full"
                    style={{ width: `${Math.min(progress, 100)}%` }}
                  ></div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
      {projects.length === 0 && (
          <div className="text-center py-10 px-4">
              <p className="text-slate-500">No projects yet.</p>
              <p className="text-sm text-slate-400 mt-1">Click the '+' button to add your first project.</p>
          </div>
      )}
    </div>
  );
};

export default ProjectList;
