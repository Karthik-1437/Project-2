
export interface Expense {
  id: string;
  description: string;
  amount: number;
  category: string;
  date: string;
}

export interface Project {
  id: string;
  name: string;
  budget: number;
  expenses: Expense[];
}
