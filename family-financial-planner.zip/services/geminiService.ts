
import { GoogleGenAI } from "@google/genai";
import type { Project } from '../types';
import { Remarkable } from 'remarkable';

const md = new Remarkable();

// This function assumes the API_KEY is set in the environment
const getApiKey = () => {
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
      throw new Error("API_KEY environment variable not set.");
    }
    return apiKey;
};

let ai: GoogleGenAI;
try {
  ai = new GoogleGenAI({ apiKey: getApiKey() });
} catch (error) {
  console.error(error);
}

export const getFinancialAdvice = async (project: Project, userQuery: string): Promise<string> => {
    if (!ai) {
        throw new Error("GoogleGenAI client is not initialized. Check your API key.");
    }

  const totalSpent = project.expenses.reduce((sum, exp) => sum + exp.amount, 0);
  const simplifiedExpenses = project.expenses.map(e => ({ category: e.category, amount: e.amount }));

  const prompt = `
    You are a friendly and expert financial advisor for household projects.
    Your goal is to provide clear, actionable, and encouraging advice to help users manage their finances effectively.

    Here are the details of the user's current project:
    - Project Name: ${project.name}
    - Total Budget: $${project.budget.toLocaleString()}
    - Total Spent so Far: $${totalSpent.toLocaleString()}
    - Expenses Breakdown: ${JSON.stringify(simplifiedExpenses, null, 2)}

    The user has the following question: "${userQuery}"

    Please provide a helpful and concise response. Format your response using markdown.
    - Use headings, bullet points, or numbered lists to make the advice easy to read.
    - Be positive and supportive in your tone.
    - If you provide suggestions, make them practical and relevant to the project context.
    `;

  try {
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt
    });

    const text = response.text;
    return md.render(text);
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    throw new Error("Failed to get financial advice from the AI model.");
  }
};
